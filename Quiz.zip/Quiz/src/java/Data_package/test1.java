/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_package;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static java.io.FileDescriptor.out;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author Tathagat
 */
public class test1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) 
        {
            
            
           /* quesno=request.getParameter("questno");
            question=request.getParameter("question");
            A=request.getParameter("A");
            B=request.getParameter("B");
            C=request.getParameter("C");
            D=request.getParameter("D");
            ans=request.getParameter("ans");*/
           Connection conn;
           RequestDispatcher rd;
          
            try {
                String quesno;
            String question;
            String A=null,B=null,C=null,D=null,ans;
            
                Class.forName("com.mysql.jdbc.Driver");
                conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Quiz","root","root");
               PreparedStatement ps = conn.prepareStatement("select * from sawal");
               ResultSet rs=null;
               while(rs.next())
               {
                quesno=rs.getString(1);
               question=rs.getString(2);
               A=rs.getString(3);
               B=rs.getString(4);
               C=rs.getString(5);
               D=rs.getString(6);
               ans=rs.getString(7);
               }
               out.println(A);
               rs=ps.executeQuery();
               
               
              System.out.println("New Record Added successfully"); 
               conn.close();
               ps.close();
                //RequestDispatcher dispachter = request.getRequestDispatcher("Quiz-select.jsp");
                //dispachter.forward(request, response);
                response.sendRedirect("signup.jsp"); 
           }
            catch(SQLException e)
                {
                 System.out.println(e);
                }
          
        }
             catch (Exception e)
		{
                    e.printStackTrace();
		}
            
        }
    }


    