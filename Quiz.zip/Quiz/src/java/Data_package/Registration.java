/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_package;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Tathagat
 */
public class Registration extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String fname,pass,mnumber,email;
            
            fname=request.getParameter("fname");
            email=request.getParameter("email");
            mnumber=request.getParameter("mnumber");
            pass=request.getParameter("pass");
            //times=request.getParameter("times");Result
           Connection conn;
           RequestDispatcher rd;
         
            try {
                
                Class.forName("com.mysql.jdbc.Driver");
                conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Quiz","root","root");
               PreparedStatement ps = conn.prepareStatement("insert into quiz values(?,?,?,?)");
               ps.setString(1,fname);
               ps.setString(2,email);
               ps.setString(3,mnumber);
               ps.setString(4,pass);
                
              
              System.out.println("New Record Added successfully"); 
             
                ps.executeUpdate();
                 conn.close();
               ps.close();
                rd=request.getRequestDispatcher("Quiz-select.jsp");
                rd.forward(request, response);
               // response.sendRedirect("Quiz-select.jsp"); 
                
                
            }
               
            
            catch(SQLException e)
                {
                 System.out.println(e);
                }
          
        }
          catch (Exception e)
	{
         System.out.println("Exception");
	}
    }
    
  
}
