/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tathagat
 */
public class Connect {
    
    public String getpath()
    {
       String path="D:/quiz/quizdb.mdb"; //specify where your database resides.
       return path;
    }
}
